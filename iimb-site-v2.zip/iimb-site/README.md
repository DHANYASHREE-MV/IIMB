# IIMB — The Bengaluru Edit (local build)

Plain HTML/CSS/JS. No install, no build step.

## Run
Option A: double-click `index.html` (all links are relative, so it works from disk).
Option B (recommended): in this folder run `python -m http.server 5500`, then open http://localhost:5500
Option C: VS Code > Live Server > Go Live.

## Pages
index.html · about.html · programmes.html · faculty.html · research.html · giving.html
New in this update: **centres.html** · **campus-life.html** · **news-events.html**
About subpages: chairperson.html · director.html · board.html

## What changed in this update
- Three new pages: Centres of Excellence (filterable index + reader panel), Campus Life (Doshi's architecture,
  a scroll-driven corridor walk, living, library, sport, clubs, sustainability), News & Events (lead story,
  latest news, a filterable events agenda to March 2027, more headlines).
- Programmes page opens like the reference: light header, motto, programme card carousel (now 5 programmes).
- Real photos: 61 images at up to 1920px, from iimb.ac.in and Wikimedia Commons (Commons credits in the footer,
  "Photo credits"). Every photo prints in black and white; colour develops from the cursor on hover
  (tap on touch screens).
- Homepage events are the real October–November 2026 listings with links.
- Motion (css/motion.css + js/motion.js): pergola-beam hero reveal, masked headline lines, photos that rise in
  as they arrive, header that tucks away on scroll with a red reading-progress line, page-to-page cross-fade
  (View Transitions), FLIP filtering. All of it respects "reduce motion".

## Structure
- css/styles.css   original homepage styles
- css/pages.css    shared page system
- css/motion.css   motion layer + styles for the three new pages
- js/data.js       images + content for the original pages
- js/content.js    content for the new pages (news, events, centres, campus) + photo credits
- js/site.js       shared on EVERY page: header/nav, footer, renderers, carousel, reveals
- js/motion.js     colour-develop hover, hero reveal, header, corridor walk, filters
- js/main.js       homepage-only timeline, events and counters
Edit the nav once in js/site.js (NAV / SUB) and it updates everywhere.

## Content sources
Text comes from iimb.ac.in (retrieved 18 Oct 2026): Life @IIMB, Student Life, Centres of Excellence, news and
the homepage events list. Re-verify before publishing; dates and rankings change.
