Put your photos here (extracted from your PDF). Expected names:

hero-campus.jpg            advantage-campus.jpg
prog-pgp.jpg               prog-bsc-data-science.jpg
prog-phd.jpg               prog-exec-ed.jpg
events-auditorium.jpg
priority-nation-main.jpg   priority-nation-2.jpg  priority-nation-3.jpg  priority-nation-4.jpg
priority-sustain-main.jpg  priority-sustain-2.jpg priority-sustain-3.jpg priority-sustain-4.jpg
journey-1972.jpg  journey-1973.jpg  journey-1976.jpg  journey-1978.jpg  journey-1983.jpg

Save the PICTURES IN COLOUR. The page turns them black & white with CSS and shows colour on hover.
To use different names, edit js/data.js (IMG object).
