Faculty portraits for the "Faculty by research topic" section.
Save each official IIMB profile photo here (colour is fine; the page turns it black & white and shows colour on hover):

  u-dinesh-kumar.jpg         (profile: https://www.iimb.ac.in/user/70/u-dinesh-kumar)
  rahul-de.jpg               (profile: https://iimb.ac.in/index.php/user/67/rahul-de)
  venkatesh-panchapagesan.jpg (profile: https://www.iimb.ac.in/user/119/venkatesh-panchapagesan)
  sourav-mukherji.jpg        (profile: https://www.iimb.ac.in/user/106/sourav-mukherji)
  shashidhar-murthy.jpg      (profile: https://www.iimb.ac.in/hi/user/111)

Load order per person: this folder -> official hotlink (if listed in js/data.js) -> initials block.
To add a person, add an entry to FACULTY in js/data.js and an IMG key "f-<slug>".
