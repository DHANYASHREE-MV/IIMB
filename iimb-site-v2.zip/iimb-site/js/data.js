/* ===== IMAGE PATHS =====
   Put your photos (extracted from your PDF) in assets/images/ with these names.
   Load order: local file -> fallback URLs (template's own images) -> grey placeholder. */
const IMG_DIR = "assets/images/";
const IIMB = "https://www.iimb.ac.in/sites/default/files/inline-images/";
const UNS = "https://images.unsplash.com/";
const IMG = {
   "hero": { file: "hero-campus.jpg", fb: [IIMB + "architecture-1.jpg", UNS + "photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=2000&q=85"] },
   "advantage": { file: "advantage-campus.jpg", fb: [IIMB + "architecture-2.jpg", UNS + "photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=85"] },
   "pgp": { file: "prog-pgp.jpg", fb: [IIMB + "architecture-3.jpg"] },
   "bsc": { file: "prog-bsc-data-science.jpg", fb: [IIMB + "architecture-4.jpg"] },
   "phd": { file: "prog-phd.jpg", fb: [IIMB + "architecture-5.jpg"] },
   "execed": { file: "prog-exec-ed.jpg", fb: [IIMB + "architecture-6.jpg"] },
   "pgppm": { file: "prog-pgppm.jpg", fb: [] },
   "auditorium": { file: "events-auditorium.jpg", fb: [IIMB + "architecture-7.jpg"] },
   "nation-main": { file: "priority-nation-main.jpg", fb: [IIMB + "architecture-8.jpg", UNS + "photo-1562774053-701939374585?auto=format&fit=crop&w=900&q=80"] },
   "nation-2": { file: "priority-nation-2.jpg", fb: [UNS + "photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=900&q=80"] },
   "nation-3": { file: "priority-nation-3.jpg", fb: [] },
   "nation-4": { file: "priority-nation-4.jpg", fb: [] },
   "sustain-main": { file: "priority-sustain-main.jpg", fb: [UNS + "photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=900&q=80"] },
   "sustain-2": { file: "priority-sustain-2.jpg", fb: [] },
   "sustain-3": { file: "priority-sustain-3.jpg", fb: [] },
   "sustain-4": { file: "priority-sustain-4.jpg", fb: [] },
   "j1972": { file: "journey-1972.jpg", fb: [] },
   "j1973": { file: "journey-1973.jpg", fb: [] },
   "j1976": { file: "journey-1976.jpg", fb: [] },
   "j1978": { file: "journey-1978.jpg", fb: [] },
   "j1983": { file: "journey-1983.jpg", fb: [UNS + "photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1000&q=80"] }
};

/* ===== CONTENT (verify before publishing) ===== */
const PROGS = [
   { k: "pgp", t: "Post Graduate Programme in Management (PGP)", d: "A transformative two-year residential programme to develop responsible, future-ready leaders.", u: "https://www.iimb.ac.in/programmes/pgp" },
   { k: "bsc", t: "Bachelor of Science (Data Science and AI)", d: "A multidisciplinary undergraduate programme that blends data, technology and management for real-world impact.", u: "https://ug.iimb.ac.in/programmes/bsc-honours-data-sciences/" },
   { k: "phd", t: "PhD Programme", d: "An intellectually stimulating programme for scholars who aim to create new knowledge and shape the future of business and society.", u: "https://www.iimb.ac.in/programmes/doctoral-programme" },
   { k: "execed", t: "Executive Education", d: "Customised and open programmes for experienced professionals and organisations to stay ahead in a changing world.", u: "https://eep.iimb.ac.in" },
   { k: "pgppm", t: "Public Policy and Management (PGPPM)", d: "A one-year programme for public servants and policy professionals, now in its 23rd cohort.", u: "https://www.iimb.ac.in/programmes/pgppm" }
];
/* Upcoming events, from the iimb.ac.in homepage (retrieved 18 Oct 2026). Re-verify before publishing. */
const EVENTS = [
   { d: "22", m: "Oct 2026", t: "Does Bank Lending to Nonbanks Affect Credit Allocation and Systemic Risk?", c: "Research seminar · R&P Office", u: "https://www.iimb.ac.in/node/10906" },
   { d: "28", m: "Oct 2026", t: "53rd Foundation Day: India's Energy Journey, a lecture by IndianOil Chairman A S Sahney", c: "Institute · Foundation Day", u: "https://www.iimb.ac.in/iimb-to-celebrate-53rd-foundation-day" },
   { d: "02", m: "Nov 2026", t: "Nurturing Future Leadership Programme (NFLP), seventh cohort", c: "Centre for Teaching & Learning", u: "https://www.iimb.ac.in/node/683" },
   { d: "20", m: "Nov 2026", t: "International Corporate Governance & Sustainability Conference 2026", c: "CCGS · Conference", u: "https://www.iimb.ac.in/node/10481" }
];
const MILES = [
   { y: 1972, k: "j1972", t: "An institution takes shape", d: "IIM Bangalore was registered as a society on 27 March 1972, laying the groundwork for a new institution dedicated to management education in India." },
   { y: 1973, k: "j1973", t: "The formal inauguration", d: "Prime Minister Indira Gandhi formally inaugurated IIM Bangalore on 28 October 1973. Classes began in temporary premises in Bengaluru." },
   { y: 1976, k: "j1976", t: "The first graduating cohort", d: "IIMB held its first annual convocation on 10 July 1976, marking an important milestone in the Institute's academic journey." },
   { y: 1978, k: "j1978", t: "Building a permanent home", d: "Construction began on IIMB's permanent campus on Bannerghatta Road, beginning the development of the architectural campus." },
   { y: 1983, k: "j1983", t: "A new campus, a growing vision", d: "IIMB moved to its new campus in 1983, designed by architect B. V. Doshi, an architectural landmark that continues to inspire generations." }
];


/* ===== SHARED (all pages) ===== */
const LOCAL_FALLBACK = []; /* local mock-up images contain baked-in text, so they are not used as fallbacks */
const GIV = "https://www.iimb.ac.in/giving/images/";
Object.assign(IMG, {
   "res-hero": { file: "research-hero.jpg", fb: [] },
   "res-detail": { file: "research-detail.jpg", fb: [] },
   "about-hero": { file: "about-hero.jpg", fb: [] },
   "campus-a": { file: "about-who-we-are.jpg", fb: [] },
   "campus-main": { file: "campus-main.jpg", fb: [] },
   "logo": { file: "iimb-logo.png", fb: [IIMB + "IIMB-Logo.png"], portrait: true, ini: "IIMB" },
   "doshi": { file: "architect-bv-doshi.jpg", fb: [], portrait: true, ini: "BVD" },
   "campus-b": { file: "events-auditorium.jpg", fb: [GIV + "New-Campus2.jpg"] },
   "pt-chair": { file: "chairperson-devi-prasad-shetty.jpg", fb: [IIMB + "NH0255-Edit_2.jpg"], portrait: true, ini: "DS" },
   "pt-dir": { file: "director-u-dinesh-kumar.jpg", fb: ["https://www.iimb.ac.in/sites/default/files/2025-01/dinesh-kumar.jpg"], portrait: true, ini: "UD" },
   "giv-1": { file: "giving-empowering-students.jpg", fb: [GIV + "Empowering-Students-2026.JPG"] },
   "giv-2": { file: "giving-fostering-innovation.jpg", fb: [GIV + "Fostering-Innovation-2026.jpg"] },
   "giv-3": { file: "giving-social-impact.jpg", fb: [GIV + "Driving-Social-Impact-2026.JPG"] },
   "giv-hero": { file: "giving-campus.jpg", fb: [GIV + "New-Campus2.jpg"] }
});
const OFF = "https://www.iimb.ac.in/";
/* Source: iimb.ac.in (Board page, Chairperson page, Director profile, menus). Re-verify before publishing. */
const BOARD = [
   ["Dr. Devi Prasad Shetty", "Chairperson, Board of Governors, IIMB · Chairman and Founder, Narayana Health"],
   ["Dr. Hasmukh Adhia", "Former Finance Secretary, Government of India"],
   ["Mr. P.K. Banerjee", "Joint Secretary (Mgt. & MC & Scholarships), Ministry of Education, Government of India"],
   ["Mr. Sonjoy Chatterjee", "Chairman & CEO, Goldman Sachs (India) Securities Pvt Ltd."],
   ["Professor Jitamitra Desai", "Professor, IIMB"],
   ["Professor U Dinesh Kumar", "Director-in-charge, IIMB"],
   ["Ms. Shanti Ekambaram", "Director, Kotak Mahindra Capital Company and Director, Kotak Securities Limited"],
   ["Ms. Malavika R Harita", "Founder & CEO, Brand Circle; Former CEO, Saatchi Focus India"],
   ["Professor Sreelata Jonnalagedda", "Professor, IIMB"],
   ["Professor Das Narayandas", "Edsel Bryant Ford Professor of Business Administration, Harvard Business School"],
   ["Dr. Shalini Rajneesh, IAS", "Chief Secretary, Government of Karnataka"]
];
const DEANS = [
   ["Venkatesh Panchapagesan", "Dean (Administration)", OFF + "user/119/venkatesh-panchapagesan"],
   ["Mukta Kulkarni", "Dean (Programmes)", OFF + "user/86/mukta-kulkarni"],
   ["Sourav Mukherji", "Dean (Faculty)", OFF + "user/106/sourav-mukherji"],
   ["Vasanthi Srinivasan", "Dean (Alumni Relations & Development)", OFF + "user/145/vasanthi-srinivasan"]
];
const DEGREES = [
   ["Post Graduate Programme (PGP)", "MBA · Two-year fulltime programme", OFF + "programmes/pgp"],
   ["PGPBA", "MBA (Business Analytics) · Two-year fulltime programme", OFF + "programmes/pgpba"],
   ["EPGP", "MBA · One-year fulltime residential programme for Experienced Professionals", OFF + "programmes/epgp"],
   ["PGPEM", "MBA · Two-year programme for Working Professionals", OFF + "programmes/pgpem"],
   ["PGPPM", "Master of Management Studies (Public Policy)", OFF + "programmes/pgppm"],
   ["Doctoral Programme", "Doctor of Philosophy (PhD) · Five-year fulltime programme", OFF + "programmes/doctoral-programme"]
];
const UGPROGS = [
   ["BBA in Digital Business and Entrepreneurship", "Undergraduate · BBA DBE", "https://dbe.iimb.ac.in/"],
   ["BSc Honours, Economics", "Undergraduate", "https://ug.iimb.ac.in/programmes/bsc-economics/"],
   ["BSc Honours, Data Sciences", "Undergraduate", "https://ug.iimb.ac.in/programmes/bsc-honours-data-sciences/"],
   ["N. S. Ramaswamy Pre-doctoral Fellowship", "Certificate programme · NSR Pre-doc", OFF + "programmes/nsrpredoc"],
   ["Mahatma Gandhi National Fellowship", "Certificate programme", OFF + "mgnf"],
   ["Executive Education", "Open and customised programmes for professionals", "https://eep.iimb.ac.in"]
];
const AREAS = [
   ["Decision Sciences", OFF + "decision-sciences"], ["Economics", OFF + "economics-area"], ["Entrepreneurship", OFF + "entrepreneurship"],
   ["Finance & Accounting", OFF + "finance-account"], ["Information Systems", OFF + "faculty-information-systems"],
   ["Management Communication", OFF + "cencomm/index.php"], ["Marketing", OFF + "marketing"],
   ["Organizational Behavior & HRM", OFF + "organizational-behavior-human-resources-management"],
   ["Production & Operations", OFF + "production-operations"], ["Public Policy", OFF + "centres-of-excellence/centre_for_public_policy"],
   ["Strategy", OFF + "strategy"]
];
const CENTRES = [
   ["Capital Markets & Risk Management", OFF + "ccmrm/"], ["Corporate Governance & Sustainability", OFF + "ccgs/"],
   ["Digital Public Goods", OFF + "cdpg/"], ["Israel Centre", OFF + "centres-of-excellence/israel-centre"],
   ["Mizuho India Japan Study Centre", OFF + "mijsc/"], ["NSRCEL", "https://www.nsrcel.org/"],
   ["Software & IT Management", OFF + "centres-of-excellence/csitm"], ["Supply Chain Management", OFF + "centres-of-excellence/scmc"],
   ["Teaching & Learning", OFF + "centres-of-excellence/ctl"], ["Tony James Centre for PE & VC", OFF + "tony-james-centre/"]
];
const INITS = [
   ["Behavioural Sciences Lab", OFF + "centres-of-excellence/initiatives/behavioural-lab"],
   ["Consumer Insights", OFF + "centres-of-excellence/initiatives/consumer-insights"],
   ["Data Centre & Analytics Lab", OFF + "centres-of-excellence/initiatives/dcal"],
   ["Health Economics & Policy", OFF + "health-economics-policy/"], ["PHC4UHC", OFF + "phc4uhc/"],
   ["Real Estate Research", OFF + "reri/"]
];


/* ===== FACULTY BY RESEARCH TOPIC =====
   Research topics are taken from each person's official IIMB profile (or, for Venkatesh Panchapagesan's topics, the IGC profile).
   Re-verify before publishing. Photos: save into assets/images/faculty/ (see README there). */
const FTHEMES = { ai: "Data, AI & analytics", ops: "Operations & reliability", dig: "Digital & public systems", fin: "Markets & finance", org: "Organisations & inclusive business" };
const FACULTY = [
   { slug: "u-dinesh-kumar", n: "U Dinesh Kumar", s: "Dinesh Kumar", role: "Professor · Decision Sciences", u: "https://www.iimb.ac.in/user/70/u-dinesh-kumar", ini: "UD",
     t: [["Business Analytics & Big Data", "ai"], ["Artificial Intelligence", "ai"], ["Machine Learning", "ai"], ["Deep Learning", "ai"], ["Reinforcement Learning", "ai"], ["Reliability", "ops"], ["Optimization", "ops"], ["Six Sigma", "ops"], ["Performance Based Logistics", "ops"]] },
   { slug: "rahul-de", n: "Rahul Dé", s: "Rahul Dé", role: "Professor · Information Systems", u: "https://iimb.ac.in/index.php/user/67/rahul-de", ini: "RD",
     t: [["AI Ethics", "ai"], ["e-Government Systems", "dig"], ["Open Source", "dig"], ["Digital Payments", "dig"], ["Tele-medicine", "dig"], ["ICT for Development", "dig"]] },
   { slug: "venkatesh-panchapagesan", n: "Venkatesh Panchapagesan", s: "Venkatesh P.", role: "Finance & Accounting", u: "https://www.iimb.ac.in/user/119/venkatesh-panchapagesan", ini: "VP",
     t: [["Market Microstructure", "fin"], ["Mutual Funds", "fin"], ["Real Estate", "fin"]] },
   { slug: "sourav-mukherji", n: "Sourav Mukherji", s: "Sourav Mukherji", role: "Organizational Behaviour & HRM", u: "https://www.iimb.ac.in/user/106/sourav-mukherji", ini: "SM",
     t: [["Inclusive Business Models", "org"], ["Social Entrepreneurship", "org"], ["Corporate Social Responsibility", "org"], ["Organization Design", "org"]] },
   { slug: "shashidhar-murthy", n: "Shashidhar Murthy", s: "Shashidhar Murthy", role: "Associate Professor · Finance & Control", u: "https://www.iimb.ac.in/hi/user/111", ini: "SM",
     t: [["Asset Pricing", "fin"], ["Investor Heterogeneity", "fin"]] }
];
Object.assign(IMG, {
   "f-u-dinesh-kumar": { file: "faculty/u-dinesh-kumar.jpg", fb: ["https://www.iimb.ac.in/sites/default/files/2025-01/dinesh-kumar.jpg"], portrait: true, ini: "UD" },
   "f-rahul-de": { file: "faculty/rahul-de.jpg", fb: [], portrait: true, ini: "RD" },
   "f-venkatesh-panchapagesan": { file: "faculty/venkatesh-panchapagesan.jpg", fb: ["https://repository.iimb.ac.in/cris/rp/fileservice/rp12808/64/?filename=Venkatesh.jpg"], portrait: true, ini: "VP" },
   "f-sourav-mukherji": { file: "faculty/sourav-mukherji.jpg", fb: [], portrait: true, ini: "SM" },
   "f-shashidhar-murthy": { file: "faculty/shashidhar-murthy.jpg", fb: [], portrait: true, ini: "SM" }
});
