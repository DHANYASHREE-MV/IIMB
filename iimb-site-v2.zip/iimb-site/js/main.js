/* Homepage only: events list, timeline, stat counters (programme cards + carousel live in site.js) */
(function () {
    const $ = id => document.getElementById(id);

    /* ---- render lists ---- */
    $("evlist").innerHTML = EVENTS.map(e =>
        '<li><a href="' + e.u + '" target="_blank" rel="noopener"><time>' + e.d + '<small>' + e.m + '</small></time><div><h3>' + e.t + '</h3><p>' + e.c + '</p></div><i aria-hidden="true">→</i></a></li>').join("");
    $("tl").innerHTML = MILES.map(m =>
        '<article class="ms hov"><div class="img"><div class="photo" data-img="' + m.k + '" data-alt="Archival photograph, ' + m.y + '"></div></div>' +
        '<div class="cap"><span class="yr">' + m.y + '</span><h3>' + m.t + '</h3><p>' + m.d + '</p></div></article>').join("");
    $("years").innerHTML = MILES.map((m, i) => '<button type="button" data-i="' + i + '">' + m.y + '</button>').join("");
    mountPhotos($("tl"));

    /* ---- stat counters ---- */
    const fmt = n => n.toLocaleString("en-IN") + "+";
    const io = new IntersectionObserver(es => es.forEach(e => {
        if (!e.isIntersecting) return; io.disconnect();
        const reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;
        e.target.querySelectorAll("[data-n]").forEach(s => {
            const n = +s.dataset.n; if (reduce) { s.textContent = fmt(n); return }
            const t0 = performance.now(); (function f(t) { const p = Math.min((t - t0) / 1600, 1); s.textContent = fmt(Math.round(n * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(f) })(t0);
        });
    }), { threshold: .4 });
    io.observe($("stats"));

    /* ---- timeline: drag, arrows, year markers, keyboard ---- */
    const tl = $("tl"), ms = [...tl.children], yb = [...$("years").children];
    const tstep = () => ms[0].offsetWidth + 28;
    const cur = () => Math.round(tl.scrollLeft / tstep());
    const go = i => tl.scrollTo({ left: Math.max(0, Math.min(ms.length - 1, i)) * tstep(), behavior: "smooth" });
    function active() { const i = Math.min(ms.length - 1, cur()); ms.forEach((m, j) => m.classList.toggle("on", j === i)); yb.forEach((b, j) => { b.classList.toggle("on", j === i); b.setAttribute("aria-current", j === i ? "true" : "false") }) }
    tl.addEventListener("scroll", active, { passive: true }); active();
    yb.forEach((b, i) => b.onclick = () => go(i));
    $("tprev").onclick = () => go(cur() - 1); $("tnext").onclick = () => go(cur() + 1);
    tl.addEventListener("keydown", e => { if (e.key === "ArrowRight") { e.preventDefault(); go(cur() + 1) } if (e.key === "ArrowLeft") { e.preventDefault(); go(cur() - 1) } });
    let down = false, sx = 0, sl = 0;
    tl.addEventListener("pointerdown", e => { if (e.pointerType === "touch") return; down = true; sx = e.clientX; sl = tl.scrollLeft; tl.classList.add("drag") });
    addEventListener("pointermove", e => { if (down) tl.scrollLeft = sl - (e.clientX - sx) });
    addEventListener("pointerup", () => { if (down) { down = false; tl.classList.remove("drag"); go(cur()) } });
})();
