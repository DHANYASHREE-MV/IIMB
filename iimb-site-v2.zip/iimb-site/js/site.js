/* Shared across every page: header, footer, related pages, image loader, reveals, list renderers, carousel */
(function () {
    document.documentElement.classList.add("js");
    const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
    const page = document.body.dataset.page || "home", sub = document.body.dataset.sub || "";
    const NAV = [["About", "about.html", "about"], ["Programmes", "programmes.html", "programmes"], ["Faculty", "faculty.html", "faculty"], ["Research", "research.html", "research"],
        ["Centres", "centres.html", "centres"], ["Campus Life", "campus-life.html", "campus"], ["News & Events", "news-events.html", "news"], ["Giving", "giving.html", "giving"]];
    const SUB = [["Chairperson’s Message", "chairperson.html", "chairperson"], ["Director-in-charge", "director.html", "director"], ["Board and Governance", "board.html", "board"]];
    const REL = {
        about: ["About IIMB", "History, vision, campus and leadership", "about.html"],
        programmes: ["Programmes", "Degree, doctoral, undergraduate and executive education", "programmes.html"],
        faculty: ["Faculty", "The scholars, teachers and deans of IIMB", "faculty.html"],
        research: ["Research", "The IIMB Management Review, initiatives and teaching cases", "research.html"],
        centres: ["Centres", "Twelve Centres of Excellence, from NSRCEL to Digital Public Goods", "centres.html"],
        campus: ["Campus Life", "Doshi’s stone campus, hostels, clubs and sport", "campus-life.html"],
        news: ["News & Events", "What’s happening at IIMB this term", "news-events.html"],
        giving: ["Giving", "Support scholarships, research and innovation", "giving.html"],
        chairperson: ["Chairperson’s Message", "Dr Devi Prasad Shetty to the IIMB community", "chairperson.html"],
        director: ["Director-in-charge", "Professor U Dinesh Kumar", "director.html"],
        board: ["Board and Governance", "Members of the Board of Governors", "board.html"]
    };
    const pad2 = i => String(i + 1).padStart(2, "0");

    /* header */
    const link = (n, h, k) => '<a href="' + h + '"' + (page === k ? ' aria-current="page"' : '') + '>' + n + '</a>';
    const about = '<div class="has-dd">' + link("About", "about.html", "about") + '<div class="dd" aria-label="About IIMB">' +
        SUB.map(s => '<a href="' + s[1] + '"' + (sub === s[2] ? ' aria-current="page"' : '') + '>' + s[0] + '</a>').join("") + '</div></div>';
    document.body.insertAdjacentHTML("afterbegin",
        '<a class="skip" href="#top">Skip to content</a><div class="topline"></div><header class="site-header"><div class="navwrap">' +
        '<a href="index.html" class="brand" aria-label="IIM Bangalore home"><img class="logo-img" src="assets/images/iimb-logo.png" alt="IIMB logo"><span class="brandname">Indian Institute of<br>Management Bangalore<small>Knowledge · Leadership · Impact</small></span></a>' +
        '<button class="menu-toggle" id="menuToggle" aria-expanded="false" aria-controls="mainNav"><span class="mt-l">Menu</span><span class="mt-i" aria-hidden="true"><i></i><i></i></span></button>' +
        '<nav class="nav" id="mainNav" aria-label="Main navigation">' + about + NAV.slice(1).map(n => link(n[0], n[1], n[2])).join("") + '</nav></div><div class="sprog" aria-hidden="true"></div></header>');
    const nav = $("#mainNav"), mt = $("#menuToggle"), hdr = $(".site-header");
    const setMenu = o => { nav.classList.toggle("open", o); hdr.classList.toggle("menu-open", o); mt.setAttribute("aria-expanded", o); $(".mt-l", mt).textContent = o ? "Close" : "Menu" };
    mt.onclick = () => setMenu(!nav.classList.contains("open"));
    nav.addEventListener("click", e => { if (e.target.closest("a")) setMenu(false) });
    addEventListener("keydown", e => { if (e.key === "Escape" && nav.classList.contains("open")) { setMenu(false); mt.focus() } });

    /* related pages */
    const rel = $("#related");
    if (rel) rel.innerHTML = '<div class="eyebrow">Continue exploring</div><div class="rgrid">' + rel.dataset.rel.split(",").map(k => {
        const r = REL[k.trim()]; return '<a class="rcard" href="' + r[2] + '"><h3>' + r[0] + '</h3><p>' + r[1] + '</p><span class="text-link">Open <span>→</span></span></a>'
    }).join("") + '</div>';

    /* footer */
    const credits = typeof CREDITS === "undefined" ? "" : '<details class="fcred"><summary>Photo credits</summary><p>Campus photographs from Wikimedia Commons, used under Creative Commons licences; other photographs © Indian Institute of Management Bangalore.</p><ul>' +
        CREDITS.map(c => '<li><a href="https://commons.wikimedia.org/wiki/' + c[3] + '" target="_blank" rel="noopener">' + c[0] + '</a> · ' + c[1] + ' · ' + c[2] + '</li>').join("") + '</ul></details>';
    document.body.insertAdjacentHTML("beforeend",
        '<footer class="foot"><div class="fgrid"><div><div class="fbrand">Indian Institute of Management Bangalore</div><p>Bannerghatta Road, Bengaluru, India – 560076</p><p>+91 80 2699 3000</p><p><a class="ext" href="https://www.iimb.ac.in/" target="_blank" rel="noopener">Official website ↗</a></p></div>' +
        '<div><h4>Explore</h4>' + NAV.slice(0, 4).map(n => '<a href="' + n[1] + '">' + n[0] + '</a>').join("") + '</div>' +
        '<div><h4>On campus</h4>' + NAV.slice(4).map(n => '<a href="' + n[1] + '">' + n[0] + '</a>').join("") + '</div>' +
        '<div><h4>About IIMB</h4>' + SUB.map(s => '<a href="' + s[1] + '">' + s[0] + '</a>').join("") + '</div></div>' + credits +
        '<div class="fbase"><span>© Indian Institute of Management Bangalore · Concept build</span><span>The Bengaluru Edit</span></div></footer>');

    /* images: local -> official hotlink -> local campus fallback -> monogram (never a broken icon) */
    window.mountPhotos = function (root) {
        $$("[data-img]", root || document).forEach(el => {
            if (el.firstChild) return; const cfg = IMG[el.dataset.img]; if (!cfg) return;
            const alt = el.dataset.alt || "", srcs = [IMG_DIR + cfg.file, ...cfg.fb];
            if (!cfg.portrait) LOCAL_FALLBACK.forEach(f => { if (!srcs.includes(IMG_DIR + f)) srcs.push(IMG_DIR + f) });
            let i = 0; const im = new Image(); im.alt = alt; im.loading = el.closest(".hero,.phero,.rhero,.walk,.track,.tl") ? "eager" : "lazy"; im.decoding = "async";
            im.onerror = () => { i++; if (i < srcs.length) { im.src = srcs[i]; return } im.remove(); el.insertAdjacentHTML("beforeend", '<div class="mono-ph" role="img" aria-label="' + alt + '">' + (cfg.ini || "IIMB") + '</div>') };
            im.src = srcs[0]; el.appendChild(im);
            if (window.develop) window.develop(el);
        });
    };

    /* list renderers */
    /* abstract research motifs (decorative only): bars, trend, scatter, network, rings */
    const motif = i => {
        const k = i % 5, r = n => { const x = Math.sin((i + 1) * 12.9898 + n * 78.233) * 43758.5453; return x - Math.floor(x) };
        let g = "";
        if (k === 0) for (let n = 0; n < 9; n++) { const h = 10 + r(n) * 46; g += '<rect x="' + (8 + n * 14) + '" y="' + (64 - h) + '" width="8" height="' + h + '"/>' }
        else if (k === 1) { let d = ""; for (let n = 0; n < 10; n++) d += (n ? "L" : "M") + (6 + n * 13.5) + " " + (56 - r(n) * 40 - n * 1.2); g = '<path d="' + d + '" fill="none"/>' + [0, 3, 6, 9].map(n => '<circle cx="' + (6 + n * 13.5) + '" cy="' + (56 - r(n) * 40 - n * 1.2) + '" r="2.4"/>').join("") }
        else if (k === 2) for (let n = 0; n < 26; n++) g += '<circle cx="' + (8 + r(n) * 108) + '" cy="' + (8 + r(n + 40) * 52) + '" r="' + (1 + r(n + 80) * 2.2) + '"/>';
        else if (k === 3) { const pts = [...Array(7)].map((_, n) => [14 + r(n) * 96, 10 + r(n + 20) * 48]); pts.forEach((p, n) => { const q = pts[(n + 1 + (i % 3)) % 7]; g += '<line x1="' + p[0] + '" y1="' + p[1] + '" x2="' + q[0] + '" y2="' + q[1] + '"/>' }); g += pts.map(p => '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3"/>').join("") }
        else for (let n = 0; n < 5; n++) g += '<circle cx="62" cy="34" r="' + (6 + n * 6) + '" fill="none" stroke-dasharray="' + (n % 2 ? "2 3" : "none") + '"/>';
        return '<svg class="mo" viewBox="0 0 124 68" aria-hidden="true" focusable="false">' + g + '</svg>'
    };
    window.motif = motif;
    const ext = ' target="_blank" rel="noopener"';
    const R = {
        board: () => BOARD.map((b, i) => '<tr><td>' + pad2(i) + '</td><th scope="row">' + b[0] + '</th><td>' + b[1] + '</td></tr>').join(""),
        degrees: () => DEGREES.map((p, i) => { const pt = p[1].split(" · "), tag = pt[0], fmt = pt.slice(1).join(" · ");
            return '<a class="dcard rv" href="' + p[2] + '"' + ext + '><span class="num" aria-hidden="true">' + pad2(i) + '</span><i>↗</i><span class="tag">' + tag + '</span><h3>' + p[0] + '</h3>' + (fmt ? '<p>' + fmt + '</p>' : '') + '<b class="bar" aria-hidden="true"></b></a>' }).join(""),
        ugprogs: () => UGPROGS.map((p, i) => '<a class="row rv" href="' + p[2] + '"' + ext + '><span class="no">' + pad2(i) + '</span><div><h3>' + p[0] + '</h3><p>' + p[1] + '</p></div><i>↗</i></a>').join(""),
        areas: () => AREAS.map(a => '<a class="cell rv" href="' + a[1] + '"' + ext + '>' + a[0] + '<i>↗</i></a>').join(""),
        centres: () => CENTRES_FULL.map((a, i) => '<a class="ccard rv" href="' + a[3] + '"' + ext + '><span class="code">' + a[0] + '</span><i>↗</i>' + motif(i) + '<h3>' + a[1] + '</h3></a>').join(""),
        inits: () => INITS.map((a, i) => '<a class="toc-i rv" href="' + a[1] + '"' + ext + '><span class="tn">' + pad2(i) + '</span><span class="tt">' + a[0] + '</span><span class="td" aria-hidden="true"></span><i>↗</i></a>').join(""),
        rstats: () => [[CENTRES_FULL.length, "Centres of Excellence"], [INITS.length, "Research initiatives"], [AREAS.length, "Academic areas"], [1, "Journal of its own"]].map(x => '<div><strong data-n="' + x[0] + '">0</strong><span>' + x[1] + '</span></div>').join(""),
        deans: () => DEANS.map((d, i) => '<a class="dean2 rv" href="' + d[2] + '"' + ext + '><div class="ph2" role="img" aria-label="Portrait of ' + d[0] + ' to be added"><span class="in">' + d[0].split(" ").map(w => w[0]).slice(0, 2).join("") + '</span><span class="ix">' + pad2(i) + '</span></div><h3>' + d[0] + '</h3><p>' + d[1] + '</p><i>↗</i></a>').join(""),
        /* shared programme card (home + programmes page) */
        progcards: () => PROGS.map(p => '<a class="card hov" href="' + p.u + '"' + ext + '><div class="img"><div class="photo" data-img="' + p.k + '" data-alt="' + p.t + '"></div></div>' +
            '<div class="body"><h3>' + p.t + '</h3><div class="bar"></div><p>' + p.d + '</p><span class="text-link">Explore Programme <span>→</span></span></div></a>').join(""),
        /* campus life */
        walk: () => WALK.map((w, i) => '<figure class="wk hov' + (i % 2 ? ' lo' : '') + '"><div class="wk-ph"><div class="photo" data-img="' + w[0] + '" data-alt="' + w[1] + ', IIMB campus"></div></div><figcaption><span class="wk-n">' + pad2(i) + '</span><b>' + w[1] + '</b><span>' + w[2] + '</span></figcaption></figure>').join(""),
        lifestats: () => LIFE_STATS.map(s => '<div><strong data-n="' + s[0] + '" data-s="' + s[1] + '">0</strong><span>' + s[2] + '</span></div>').join(""),
        clubs: () => CLUBS.map(c => '<article class="club hov rv" tabindex="0"><div class="club-ph"><div class="photo" data-img="' + c[2] + '" data-alt="' + c[0] + ' at IIMB"></div></div><div class="club-tx"><h3>' + c[0] + '</h3><p>' + c[1] + '</p></div></article>').join(""),
        sports: () => SPORTS.map(s => '<li>' + s + '</li>').join(""),
        /* news & events */
        newslead: () => '<a class="nlead hov" href="' + NEWS_LEAD.u + '"' + ext + '><div class="nlead-ph"><div class="photo" data-img="' + NEWS_LEAD.k + '" data-alt="Signing of the IIT Kanpur and NSRCEL MoU"></div></div><div class="nlead-tx"><span class="nmeta"><b>' + NEWS_LEAD.c + '</b><time>' + NEWS_LEAD.d + '</time></span><h2>' + NEWS_LEAD.t + '</h2><p>' + NEWS_LEAD.p + '</p><span class="text-link">Read the story <span>↗</span></span></div></a>',
        news: () => NEWS.map(n => '<a class="ncard hov rv" href="' + n.u + '"' + ext + '><div class="ncard-ph"><div class="photo" data-img="' + n.k + '" data-alt=""></div></div><span class="nmeta"><b>' + n.c + '</b><time>' + n.d + '</time></span><h3>' + n.t + '</h3><p>' + n.p + '</p></a>').join(""),
        headlines: () => HEADLINES.map(h => '<li><a href="' + h.u + '"' + ext + '><b>' + h.c + '</b><span>' + h.t + '</span><i>↗</i></a></li>').join(""),
        evfilters: () => ["All", ...new Set(EVENTS_ALL.map(e => e.c))].map((c, i) => '<button type="button" aria-pressed="' + (i ? "false" : "true") + '" data-f="' + c + '">' + c + '<span>' + (i ? EVENTS_ALL.filter(e => e.c === c).length : EVENTS_ALL.length) + '</span></button>').join(""),
        events: () => { let last = ""; return EVENTS_ALL.map(e => { const mh = e.m + " " + e.y, head = mh !== last ? '<li class="evm" data-m="' + mh + '"><span>' + mh + '</span></li>' : ""; last = mh;
            return head + '<li class="evi" data-c="' + e.c + '" data-m="' + mh + '"><a href="' + e.u + '"' + ext + '><time><b>' + e.d + '</b>' + e.m + '</time><div><span class="evc">' + e.c + '</span><h3>' + e.t + '</h3><p>' + e.h + '</p></div><i>↗</i></a></li>' }).join("") },
        /* centres */
        cindex: () => CENTRES_FULL.map((c, i) => '<li><a class="cx" href="' + c[3] + '"' + ext + ' data-i="' + i + '"><span class="cx-n">' + pad2(i) + '</span><span class="cx-t">' + c[1] + '</span><span class="cx-f">' + c[4] + '</span><span class="cx-d">' + c[2] + '</span><i>↗</i></a></li>').join(""),
        cfields: () => ["All", ...new Set(CENTRES_FULL.map(c => c[4]))].map((f, i) => '<button type="button" aria-pressed="' + (i ? "false" : "true") + '" data-f="' + f + '">' + f + '</button>').join("")
    };
    $$("[data-render]").forEach(el => { if (R[el.dataset.render]) el.innerHTML = R[el.dataset.render]() });

    mountPhotos();

    /* touch: first tap develops colour, second tap follows the link */
    document.addEventListener("click", e => {
        if (!matchMedia("(hover:none)").matches) return;
        const el = e.target.closest(".hov"); if (!el) return;
        if (el.tagName === "A" && !el.classList.contains("on")) e.preventDefault();
        $$(".hov.on").forEach(o => o !== el && o.classList.remove("on"));
        el.classList.toggle("on");
    });

    /* carousel: arrows, dots, keyboard; used by the programme cards on home and Programmes */
    window.carousel = function (track, dots, prev, next) {
        if (!track || !track.children.length) return;
        const step = () => track.firstElementChild.offsetWidth + parseFloat(getComputedStyle(track).columnGap || 20);
        const n = track.children.length;
        if (dots) {
            dots.innerHTML = [...track.children].map((_, i) => '<button type="button" aria-label="Go to programme ' + (i + 1) + ' of ' + n + '"></button>').join("");
            [...dots.children].forEach((b, i) => b.onclick = () => track.scrollTo({ left: i * step(), behavior: "smooth" }));
        }
        const upd = () => {
            const i = Math.round(track.scrollLeft / step()), end = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
            const cur = end ? n - 1 : i;
            if (dots) [...dots.children].forEach((b, j) => { b.classList.toggle("on", j === cur); b.setAttribute("aria-current", j === cur ? "true" : "false") });
            if (prev) prev.disabled = track.scrollLeft < 4; if (next) next.disabled = end;
        };
        track.addEventListener("scroll", upd, { passive: true }); addEventListener("resize", upd); upd();
        if (prev) prev.onclick = () => track.scrollBy({ left: -step(), behavior: "smooth" });
        if (next) next.onclick = () => track.scrollBy({ left: step(), behavior: "smooth" });
        track.addEventListener("keydown", e => { if (e.key === "ArrowRight") { e.preventDefault(); track.scrollBy({ left: step(), behavior: "smooth" }) } if (e.key === "ArrowLeft") { e.preventDefault(); track.scrollBy({ left: -step(), behavior: "smooth" }) } });
    };
    $$("[data-carousel]").forEach(w => carousel($(".track", w), $(".dots", w), $(".prev", w), $(".next", w)));

    /* scroll reveals + counters */
    const reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target) } }), { threshold: .12, rootMargin: "0px 0px -6% 0px" });
    window.observeReveal = root => $$(".rv", root || document).forEach(el => io.observe(el));
    observeReveal();
    const cio = new IntersectionObserver(es => es.forEach(e => {
        if (!e.isIntersecting) return; cio.unobserve(e.target);
        $$("[data-n]", e.target).forEach(s => { const n = +s.dataset.n, suf = s.dataset.s || "";
            if (reduce) { s.textContent = n.toLocaleString("en-IN") + suf; return }
            const t0 = performance.now(); (function f(t) { const p = Math.min((t - t0) / 1400, 1); s.textContent = Math.round(n * (1 - Math.pow(1 - p, 3))).toLocaleString("en-IN") + suf; if (p < 1) requestAnimationFrame(f) })(t0) });
    }), { threshold: .4 });
    $$(".cnt").forEach(el => cio.observe(el));
})();
