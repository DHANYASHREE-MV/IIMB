/* Faculty by research topic: a main portrait with the other faculty fanning out from behind it. */
(function () {
    const stage = document.getElementById("fstage"), idx = document.getElementById("ftopics");
    if (!stage || typeof FACULTY === "undefined") return;
    const n = FACULTY.length; let cur = 0;
    const pad = i => String(i + 1).padStart(2, "0");
    const chips = f => f.t.map(t => '<span class="tg tg-' + t[1] + '">' + t[0] + '</span>').join("");

    stage.innerHTML =
        '<div class="fdeck" id="fdeck" role="group" aria-label="Faculty portraits">' + FACULTY.map((f, i) =>
            '<button type="button" class="fcard hov" data-i="' + i + '" aria-label="Show ' + f.n + '"><div class="photo" data-img="f-' + f.slug + '" data-alt="Portrait of ' + f.n + '"></div><span class="fn">' + f.s + '</span></button>').join("") + '</div>' +
        '<div class="finfo" aria-live="polite"><div id="fbody"></div>' +
        '<div class="fctl"><button type="button" id="fprev" aria-label="Previous faculty">←</button><span id="fcount"></span><button type="button" id="fnext" aria-label="Next faculty">→</button></div></div>';
    const cards = [...stage.querySelectorAll(".fcard")], body = document.getElementById("fbody"), deck = document.getElementById("fdeck");
    if (window.mountPhotos) mountPhotos(stage);

    function paint(animate) {
        const f = FACULTY[cur];
        cards.forEach((c, i) => { const p = (i - cur + n) % n; c.style.setProperty("--p", p); c.classList.toggle("main", p === 0); c.tabIndex = 0; c.setAttribute("aria-current", p === 0 ? "true" : "false") });
        body.innerHTML = '<div class="eyebrow">' + f.role + '</div><h3>' + f.n + '</h3><div class="fl">Research topics</div><div class="tgs">' + chips(f) + '</div><a class="text-link" href="' + f.u + '" target="_blank" rel="noopener">Faculty profile <span>↗</span></a>';
        document.getElementById("fcount").textContent = pad(cur) + " / " + pad(n - 1);
        if (animate) { body.classList.remove("swap"); void body.offsetWidth; body.classList.add("swap") }
        if (idx) [...idx.querySelectorAll(".tchip")].forEach(b => b.classList.toggle("on", +b.dataset.f === cur));
    }
    const go = i => { cur = (i + n) % n; paint(true) };
    cards.forEach(c => c.addEventListener("click", () => go(+c.dataset.i)));
    document.getElementById("fprev").onclick = () => go(cur - 1);
    document.getElementById("fnext").onclick = () => go(cur + 1);
    stage.addEventListener("keydown", e => { if (e.key === "ArrowRight") go(cur + 1); if (e.key === "ArrowLeft") go(cur - 1) });

    /* topic index, grouped by theme */
    if (idx) {
        const g = {}; FACULTY.forEach((f, i) => f.t.forEach(t => (g[t[1]] = g[t[1]] || []).push([t[0], i])));
        idx.innerHTML = Object.keys(FTHEMES).filter(k => g[k]).map(k =>
            '<div class="tcol rv"><h4>' + FTHEMES[k] + '</h4>' + g[k].map(x => '<button type="button" class="tchip" data-f="' + x[1] + '">' + x[0] + '<small>' + FACULTY[x[1]].s + '</small></button>').join("") + '</div>').join("");
        idx.addEventListener("click", e => { const b = e.target.closest(".tchip"); if (!b) return; go(+b.dataset.f); stage.scrollIntoView({ behavior: "smooth", block: "center" }) });
        if (window.IntersectionObserver) { const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target) } }), { threshold: .12 }); idx.querySelectorAll(".rv").forEach(el => io.observe(el)) }
        else idx.querySelectorAll(".rv").forEach(el => el.classList.add("in"));
    }
    paint(false);

    /* intro: the other portraits slide out from behind the main one */
    const out = () => deck.classList.add("out");
    if (window.IntersectionObserver) { const o = new IntersectionObserver(es => { if (es[0].isIntersecting) { setTimeout(out, 250); o.disconnect() } }, { threshold: .35 }); o.observe(deck) } else out();
})();
