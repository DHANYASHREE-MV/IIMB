/* ===== NEW PAGES: Campus Life · News & Events · Centres =====
   Loaded after data.js on every page.
   Text from iimb.ac.in (Life @IIMB, Student Life, News, Centres of Excellence), retrieved 18 Oct 2026. Re-verify before publishing.
   Photos: official iimb.ac.in images and Wikimedia Commons (credited in CREDITS below, shown in the footer). */
const im = (file, extra) => Object.assign({ file, fb: [] }, extra || {});
Object.assign(IMG, {
   "cl-hero": im("cl-hero.jpg"), "cl-corridor-a": im("cl-corridor-a.jpg"), "cl-corridor-b": im("cl-corridor-b.jpg"),
   "cl-acadblock": im("cl-acadblock.jpg"), "cl-pergola": im("cl-pergola.jpg"), "cl-amphi": im("cl-amphi.jpg"),
   "cl-library-ext": im("cl-library-ext.jpg"), "cl-library": im("cl-library.jpg"), "cl-library-in": im("cl-library-in.jpg"),
   "cl-auditorium": im("events-auditorium.jpg"), "cl-room": im("cl-room.jpg"), "cl-hostel": im("cl-hostel.jpg"), "cl-ground": im("cl-ground.jpg"),
   "cl-dining": im("cl-dining.jpg"), "cl-mess": im("cl-mess.jpg"), "cl-dosa": im("cl-dosa.jpg"),
   "cl-sport": im("cl-sport.jpg"), "cl-basket": im("cl-basket.jpg"), "cl-hockey": im("cl-hockey.jpg"), "cl-sportscentre": im("cl-sportscentre.jpg"),
   "cl-dance": im("cl-dance.jpg"), "cl-art": im("cl-art.jpg"), "cl-friends": im("cl-friends.jpg"), "cl-lamp": im("cl-lamp.jpg"),
   "cl-sangharsh": im("cl-sangharsh.jpg"), "cl-workshop": im("cl-workshop.jpg"), "cl-computing": im("cl-computing.jpg"),
   "cl-diversity": im("cl-diversity.jpg"), "cl-entrance": im("cl-entrance.jpg"), "cl-campus4": im("cl-campus4.jpg"),
   "cl-solar": im("cl-solar.jpg"), "cl-ivy": im("cl-ivy.jpg"),
   "nw-nsrcel": im("nw-nsrcel.jpg"), "nw-pgpem": im("nw-pgpem.jpg"), "nw-phd": im("nw-phd.jpg"), "nw-ft": im("nw-ft.jpg"),
   "nw-water": im("nw-water.jpg"), "nw-convocation": im("nw-convocation.jpg"), "nw-cohort": im("nw-cohort.jpg"),
   "ce-hero": im("ce-hero.jpg"), "ce-nsrcel": im("ce-nsrcel.jpg")
});

/* Campus walk: the horizontal corridor on Campus Life */
const WALK = [
   ["cl-corridor-a", "The covered walkways", "Pergola beams throw bands of light across granite floors, linking every block without ever leaving the shade."],
   ["cl-acadblock", "Academic blocks", "Rough-cut stone, exposed concrete and deep overhangs, after the courtyards of Fatehpur Sikri."],
   ["cl-pergola", "The central pergola", "A spine of open courtyards where classes spill out between sessions."],
   ["cl-amphi", "The amphitheatre", "Stepped lawns for convocations, cultural nights and quiet afternoons."],
   ["cl-library-ext", "The library, from the amphitheatre", "Seen across the open-air theatre, the library anchors the academic core."],
   ["cl-corridor-b", "Light and column", "Completed in 1983, the stone is now wrapped in the greenery Doshi intended."]
];
const LIFE_STATS = [["1400", "+", "Students on campus"], ["52", "+", "Student clubs"], ["20", "+", "Annual events"], ["100", "", "Acre campus"]];
const CLUBS = [
   ["Culture & festivals", "Music, dance, theatre and quiz clubs, and a calendar of more than twenty annual events, Yamini among them.", "cl-dance"],
   ["Business & ideas", "Case and finance clubs, and Eximius, the entrepreneurship summit run by students.", "cl-sangharsh"],
   ["Arts & expression", "Art collectives, photography and the music room, where students learn to play and to use music for focus and calm.", "cl-art"],
   ["Service & community", "Prayaas, the student-run initiative, invites school students to pitch ideas through Youth Udyami.", "cl-friends"]
];
const SPORTS = ["Football", "Cricket", "Tennis", "Basketball", "Volleyball", "Throwball", "Badminton", "Hockey", "Indoor games", "Running club"];

/* News & events: from iimb.ac.in/recent-sliders and the homepage events list, 18 Oct 2026 */
const NEWS_LEAD = { k: "nw-nsrcel", d: "15 Oct 2026", c: "Centres", t: "IIT Kanpur and IIM Bangalore’s NSRCEL partner to strengthen India’s deep-tech and defence ecosystem",
   p: "A first-of-its-kind MoU between IIT Kanpur and NSRCEL, IIMB’s startup incubator, for joint incubation and acceleration, co-incubation and stronger links between deep-tech founders, industry and markets.", u: OFF + "iitkanpur-iimb-nsrcel-have-signed-mou" };
const NEWS = [
   { k: "nw-pgpem", d: "12 Oct 2026", c: "Rankings", t: "PGPEM enters global top 10 for salary increase in FT Executive MBA Ranking 2026", p: "The MBA for working professionals climbs eight places to #64 globally, with alumni salary growth of 102%.", u: OFF + "ft-executive-mba-ranking-2026" },
   { k: "nw-phd", d: "12 Oct 2026", c: "Research", t: "PhD Fellowships for 2026–27 and Doctoral Student Research Paper Awards announced", p: "Fourteen doctoral students recognised for academic performance, publications and the quality of ongoing research.", u: OFF + "doctoral-student-research-paper-award-2026" },
   { k: "nw-ft", d: "09 Oct 2026", c: "Rankings", t: "IIM Bangalore ranks 11th globally as the Financial Times assesses the impact of teaching cases", p: "IIMB cases were used by around 680 institutions in close to 50 countries during 2024 and 2025.", u: OFF + "iimb-ranks-11th-globally-financial-times" },
   { k: "nw-water", d: "07 Oct 2026", c: "Research", t: "New case study traces 25 years of India’s water governance, from Gujarat to the national stage", p: "From Gujarat to India: Water Lessons for the World draws four lessons for delivering water security at scale.", u: OFF + "new-case-study-gujarat-india-water-lessons-world" }
];
const HEADLINES = [
   ["Alumni", "IIMB alumnus Anup Bagchi appointed MD & CEO of HDFC Bank", "alumnus-anup-bagchi-appointed-md-ceo-HDFC-Bank"],
   ["Programmes", "380 learners graduate from IIMBx’s FinTech Certificate Programme for Young Professionals", "iimbx-fintech-certificate-programme-2026"],
   ["Centres", "CDPG and Protean eGov Technologies release the ‘State of DPI in India 2026’ report", "cdpg-annual-policy-conclave-2026"],
   ["Students", "India’s next generation of digital thinkers compete at IIMB’s National Student Case Competition", "cdpg-national-student-case-competition-2026"],
   ["Institute", "IIM Bangalore and the Ministry of Minority Affairs sign MoUs to strengthen public programme delivery", "iimb-ministry-minority-affairs-sign-mous-nmdfc"],
   ["Rankings", "PGP, PGPBA and EPGP sweep No. 1 positions in India in QS MiM, BA and Global MBA Rankings 2027", "qs-world-university-rankings-2027"],
   ["Centres", "Mizuho India Japan Study Centre hosts its 9th Foundation Day", "mijsc-9th-foundation-day"],
   ["Rankings", "EPGP clinches #2 in APAC in the Bloomberg B-School Rankings 2026", "epgp-2nd-rank-apac-bloomberg-b-school-rankings-2026"],
   ["Rankings", "PGP breaks into the global top 25 and places #1 in India in the FT Masters in Management 2026", "ft-b-school-rankings-mim-2026"],
   ["Programmes", "Applications open for BSc (Hons) Data Sciences and Economics for 2027", "iimb-ug-applications-opens-2027"],
   ["Institute", "First batch inaugurated at the IIMB – Dorabji Tata School of Undergraduate Studies", "iimb-inaugurates-first-batch-undergraduate-studies-2026"],
   ["Institute", "IIMB wins gold and three Excellence Awards at the ELCITA Sustainability Awards 2025–26", "iimb-wins-elcita-sustainability-awards-2025-26"],
   ["Programmes", "IIM Bangalore inaugurates the 23rd cohort of PGPPM", "iimb-inaugurated-23rd-cohort-pgppm-2026"],
   ["Alumni", "Four PGP alumni feature on ET’s ‘40 Under Forty’ list 2026", "pgp-alumni-et-40-under-forty-2026"]
].map(h => ({ c: h[0], t: h[1], u: OFF + h[2] }));
const EVENTS_ALL = [
   { y: "2026", m: "Oct", d: "22", c: "Seminar", t: "Does Bank Lending to Nonbanks Affect Credit Allocation and Systemic Risk?", h: "Research & Publications Office", u: OFF + "node/10906" },
   { y: "2026", m: "Oct", d: "28", c: "Institute", t: "53rd Foundation Day: ‘India’s Energy Journey’, a lecture by IndianOil Chairman Shri A S Sahney", h: "With Long Service and Alumni Service Awards", u: OFF + "iimb-to-celebrate-53rd-foundation-day" },
   { y: "2026", m: "Nov", d: "02", c: "Programme", t: "Nurturing Future Leadership Programme (NFLP), seventh cohort", h: "Centre for Teaching & Learning", u: OFF + "node/683" },
   { y: "2026", m: "Nov", d: "20", c: "Conference", t: "International Corporate Governance & Sustainability Conference 2026", h: "CCGS", u: OFF + "node/10481" },
   { y: "2026", m: "Nov", d: "28", c: "Competition", t: "GIFT Finance Olympiad: National Student Case Challenge 2026", h: "Centre for Capital Markets & Risk Management", u: OFF + "ccmrm-national-student-case-challenge-2026" },
   { y: "2026", m: "Dec", d: "01", c: "Workshop", t: "‘The India Lens: Building Theory from Indian Phenomena’, a scholarly mentorship workshop", h: "CSITM · call for papers", u: OFF + "node/768" },
   { y: "2026", m: "Dec", d: "07", c: "Workshop", t: "Winter Research Methodology Workshop 2026, 7–12 December", h: "Research & Publications Office", u: OFF + "rp-host-winter_research-methodology-workshop-2026" },
   { y: "2026", m: "Dec", d: "12", c: "Workshop", t: "AIB South Asia Chapter & AIB Sustainability SIG paper development workshop", h: "Academy of International Business", u: OFF + "node/762" },
   { y: "2026", m: "Dec", d: "13", c: "Conference", t: "India Strategy Conference 2026: ‘Ecosystems and Strategy’, 13–15 December", h: "With IIM Ahmedabad, IIM Calcutta and ISB", u: OFF + "iimb-host-india-strategy-conference-2026" },
   { y: "2027", m: "Jan", d: "11", c: "Conference", t: "18th IMR Doctoral Conference, 11–12 January 2027", h: "IIMB Management Review", u: OFF + "node/833" },
   { y: "2027", m: "Feb", d: "11", c: "Conference", t: "9th India Software Product Management Summit", h: "CSITM", u: OFF + "ispma-2027" },
   { y: "2027", m: "Mar", d: "11", c: "Workshop", t: "First Doctoral Consortium under InCIS 2027, applications open", h: "CSITM", u: OFF + "node/757" }
];

/* Centres of Excellence, with the official one-line descriptions */
const CENTRES_FULL = [
   ["CCMRM", "Capital Markets & Risk Management", "Academic leadership in research and teaching on Indian financial markets.", OFF + "ccmrm/", "Finance"],
   ["CCGS", "Corporate Governance & Sustainability", "Inaugurated in 2003 by Judge Mervyn King of South Africa; research and dialogue on boards, ethics and sustainability.", OFF + "ccgs/", "Governance"],
   ["CMC", "Management Communication", "Best practice in managerial communication, including research in emerging areas of digital communication.", OFF + "cencomm/", "Communication"],
   ["CDPG", "Digital Public Goods", "A dedicated repository of knowledge on digital public infrastructure, from research to the annual policy conclave.", OFF + "cdpg/", "Policy"],
   ["CPP", "Public Policy", "Created in 2000 through a partnership with the Department of Personnel and Training; home of the Conference on Public Policy & Management.", OFF + "centres-of-excellence/cpp", "Policy"],
   ["CSITM", "Software & IT Management", "Research, consulting, teaching and training on the management of the Indian and global software industry.", OFF + "centres-of-excellence/csitm", "Technology"],
   ["SCM", "Supply Chain Management", "Supply chain management as a major area of teaching and research, with a distinguished faculty line-up.", OFF + "centres-of-excellence/scmc", "Operations"],
   ["CTL", "Teaching & Learning", "Rethinking how management is taught as technology changes what content costs and how students learn.", OFF + "centres-of-excellence/ctl", "Pedagogy"],
   ["MIJSC", "Mizuho India Japan Study Centre", "Research collaborations and exchanges with Hitotsubashi, the International University of Japan, Keio and others.", OFF + "mijsc/", "Global"],
   ["IC", "Israel Centre", "Building on India–Israel cooperation since 1992 to promote entrepreneurship and innovation.", OFF + "centres-of-excellence/israel-centre", "Global"],
   ["NSRCEL", "N S Raghavan Centre for Entrepreneurial Learning", "IIMB’s startup incubator and accelerator, connecting the theory and practice of entrepreneurship.", "https://www.nsrcel.org/", "Entrepreneurship"],
   ["TJC", "Tony James Centre for PE & VC", "Thought leadership, education and policy influence in private equity and venture capital.", OFF + "tony-james-centre/", "Finance"]
];

/* Photo credits for Wikimedia Commons images (CC licences require attribution) */
const CREDITS = [
   ["Academic blocks at IIM Bangalore, 2012", "Magentic Manifestations", "CC BY-SA 3.0", "File:Academic_blocks_at_IIM_Bangalore,_2012.jpg"],
   ["Garden IIMB", "Apb2693", "CC BY-SA 4.0", "File:Garden_IIMB.jpg"],
   ["IIMB academic block", "Sanyam Bahga", "CC BY-SA 3.0", "File:Indian_Institute_of_Management,_Bangalore_academic_block.jpg"],
   ["DevCamp Bangalore 2012 (173)", "Manojk", "CC BY-SA 3.0", "File:DevCamp_Bangalore_2012_IMG_0482_(173).JPG"],
   ["DevCamp Bangalore 2012 (174)", "Manojk", "CC BY-SA 3.0", "File:DevCamp_Bangalore_2012_IMG_0482_(174).JPG"],
   ["IIMB Acadblock", "Magentic Manifestations", "CC BY-SA 3.0", "File:IIMB_Acadblock.JPG"],
   ["Central Pergola in 2015", "Burhan.nameer", "CC BY-SA 4.0", "File:Indian_Institute_of_Management_Bangalore,_Central_Pergola_in_2015.jpg"],
   ["Amphitheatre", "Apb2693", "CC BY-SA 4.0", "File:Indian_Institute_of_Management_Bangalore,_Amphitheatre.jpg"],
   ["Library as viewed from Amphitheatre", "Burhan.nameer", "CC BY-SA 4.0", "File:Indian_Institute_of_Management_Bangalore,_Library_as_viewed_from_Amphitheatre.jpg"],
   ["IIMB library", "Sanyam Bahga", "CC BY-SA 3.0", "File:Indian_Institute_of_Management_Bangalore_library.jpg"],
   ["Hostel blocks", "Apb2693", "CC BY-SA 4.0", "File:Hostel_blocks_at_IIM_Bangalore.jpg"],
   ["IIMB Sports Centre", "Apb2693", "CC BY-SA 4.0", "File:IIMB_Sports_Centre.jpg"],
   ["IIM Banglore (entrance)", "IM3847", "CC BY-SA 4.0", "File:IIM_Banglore.jpg"],
   ["IIMB Campus4", "Nitinku5021a", "CC BY 3.0", "File:IIMB_Campus4.jpg"],
   ["Entrance Main Block", "Apb2693", "CC BY-SA 4.0", "File:Indian_Institute_of_Management_Bangalore,_Entrance_Main_Block.jpg"]
];
