/* Motion layer, loaded last on every page.
   Thesis: the campus is shown as black-and-white prints; colour develops from wherever you touch a photo.
   Focal moment: each page hero opens like light falling through Doshi's pergola beams.
   Everything here is progressive: without JS, @property or motion, the page is complete and still. */
(function () {
    const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
    const root = document.documentElement;
    const reduce = matchMedia("(prefers-reduced-motion:reduce)");
    const canHover = matchMedia("(hover:hover)");
    const devl = !!(window.CSS && CSS.registerProperty && (CSS.supports("mask-image", "radial-gradient(#000,#000)") || CSS.supports("-webkit-mask-image", "radial-gradient(#000,#000)")));
    if (devl) root.classList.add("devl");

    /* ---------- 1. colour develops from the pointer ---------- */
    const TRIG = ".hov,.card,.ms,.lcard,.icard,.pitem,.club,.ncard,.nlead,.wk,.rcard,a";
    const groups = new Map();
    function develop(photo) {
        if (!devl || photo.dataset.dev || photo.closest(".logobox")) return;
        const base = photo.querySelector("img"); if (!base) return;
        photo.dataset.dev = "1";
        const make = () => {
            if (photo.querySelector(".clr")) return;
            base.classList.add("bw");
            const c = new Image(); c.className = "clr"; c.alt = ""; c.setAttribute("aria-hidden", "true"); c.decoding = "async";
            c.src = base.currentSrc || base.src; photo.appendChild(c);
        };
        if (base.complete && base.naturalWidth) make(); else base.addEventListener("load", make, { once: true });
        const trig = photo.closest(TRIG) || photo.closest(".imgbox,.rh-ph,.cs-ph") || photo;
        if (!groups.has(trig)) { groups.set(trig, []); bind(trig) }
        groups.get(trig).push(photo);
    }
    function light(trig, x, y) {
        groups.get(trig).forEach(p => {
            const r = p.getBoundingClientRect();
            const mx = x == null ? 50 : Math.max(0, Math.min(100, (x - r.left) / r.width * 100));
            const my = y == null ? 50 : Math.max(0, Math.min(100, (y - r.top) / r.height * 100));
            p.style.setProperty("--mx", mx + "%"); p.style.setProperty("--my", my + "%"); p.classList.add("lit");
        });
    }
    const dark = trig => groups.get(trig).forEach(p => p.classList.remove("lit"));
    function bind(t) {
        t.addEventListener("pointerenter", e => { if (e.pointerType === "mouse" || canHover.matches) light(t, e.clientX, e.clientY) });
        t.addEventListener("pointerleave", e => { if (e.pointerType === "mouse" || canHover.matches) dark(t) });
        t.addEventListener("focusin", () => light(t));
        t.addEventListener("focusout", e => { if (!t.contains(e.relatedTarget)) dark(t) });
    }
    window.develop = develop;
    $$(".photo").forEach(develop);

    /* ---------- 2. focal: pergola light opens the hero ---------- */
    $$(".hero,.phero,.rhero,.cl-hero,.ce-hero").forEach(h => {
        /* headline lines rise out of a mask, one per <br> */
        const h1 = $("h1", h);
        if (h1 && !h1.dataset.split) {
            h1.dataset.split = "1";
            h1.innerHTML = h1.innerHTML.split(/<br\s*\/?>/i).map((l, i) => '<span class="ln"><span style="--d:' + i + '">' + l + '</span></span>').join("");
        }
        const ph = $(".rh-ph", h) || h;
        if (!reduce.matches && !$(".slats", ph)) $(".photo", ph).insertAdjacentHTML("afterend", '<div class="slats" aria-hidden="true">' + [...Array(9)].map((_, i) => '<i style="--i:' + i + '"></i>').join("") + '</div>');
        const img = $(".photo img", h), go = () => requestAnimationFrame(() => requestAnimationFrame(() => h.classList.add("ready")));
        if (!img || reduce.matches) return go();
        if (img.complete && img.naturalWidth) go(); else { img.addEventListener("load", go, { once: true }); img.addEventListener("error", go, { once: true }); setTimeout(go, 1600) }
    });

    /* ---------- 3. photographs print in as they arrive ---------- */
    const wipeSel = ".imgbox,.club-ph,.ncard-ph,.nlead-ph,.cs-ph,.gal figure";
    const wio = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("printed"); wio.unobserve(e.target) } }), { threshold: .18, rootMargin: "0px 0px -4% 0px" });
    $$(wipeSel).forEach(el => { if (el.closest(".hero,.phero,.rhero,.cl-hero")) return; el.classList.add("print"); wio.observe(el) });

    /* ---------- 4. header: tucks away on the way down, returns on the way up; reading progress ---------- */
    const hdr = $(".site-header"), bar = $(".sprog");
    let lastY = scrollY, ticking = false;
    function onScroll() {
        const y = scrollY, max = document.documentElement.scrollHeight - innerHeight;
        if (bar) bar.style.transform = "scaleX(" + (max > 0 ? Math.min(1, y / max) : 0) + ")";
        if (hdr) {
            hdr.classList.toggle("scrolled", y > 24);
            const menu = hdr.classList.contains("menu-open") || hdr.matches(":focus-within");
            if (!menu && y > 260 && y > lastY + 6) hdr.classList.add("tuck");
            else if (y < lastY - 6 || y < 260 || menu) hdr.classList.remove("tuck");
        }
        lastY = y; ticking = false;
    }
    addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll) } }, { passive: true }); onScroll();

    /* ---------- 5. campus life: walk the corridor (vertical scroll drives a horizontal walk) ---------- */
    const walk = $(".walk");
    if (walk) {
        const pin = $(".walk-pin", walk), track = $(".walk-track", walk), meter = $(".walk-meter i", walk), count = $(".walk-count b", walk);
        const figs = $$(".wk", track);
        let on = false, dist = 0;
        const mq = matchMedia("(min-width:900px)");
        function layout() {
            on = mq.matches && !reduce.matches;
            walk.classList.toggle("pinned", on);
            if (!on) { walk.style.height = ""; track.style.transform = ""; return }
            dist = Math.max(0, track.scrollWidth - innerWidth + parseFloat(getComputedStyle(track).paddingLeft));
            walk.style.height = (innerHeight + dist) + "px"; step();
        }
        function step() {
            if (!on) return;
            const r = walk.getBoundingClientRect(), p = Math.max(0, Math.min(1, -r.top / Math.max(1, walk.offsetHeight - innerHeight)));
            track.style.transform = "translate3d(" + (-p * dist) + "px,0,0)";
            if (meter) meter.style.transform = "scaleX(" + p + ")";
            const i = Math.min(figs.length - 1, Math.round(p * (figs.length - 1)));
            if (count) count.textContent = String(i + 1).padStart(2, "0");
            figs.forEach((f, j) => f.classList.toggle("near", j === i));
        }
        let wt = false;
        addEventListener("scroll", () => { if (on && !wt) { wt = true; requestAnimationFrame(() => { step(); wt = false }) } }, { passive: true });
        addEventListener("resize", layout); mq.addEventListener("change", layout); reduce.addEventListener("change", layout);
        if (document.readyState === "complete") layout(); else addEventListener("load", layout); layout();
    }

    /* ---------- 6. filters that rearrange with FLIP (events list, centres index) ---------- */
    function flipFilter(bar, items, match, after) {
        if (!bar) return;
        bar.addEventListener("click", e => {
            const b = e.target.closest("button"); if (!b) return;
            $$("button", bar).forEach(x => x.setAttribute("aria-pressed", x === b ? "true" : "false"));
            const f = b.dataset.f, first = new Map(items().map(el => [el, el.getBoundingClientRect()]));
            items().forEach(el => el.hidden = !(f === "All" || match(el, f)));
            if (after) after(f);
            if (reduce.matches) return;
            items().forEach(el => {
                if (el.hidden) return;
                const a = first.get(el), z = el.getBoundingClientRect();
                if (a && a.height) el.animate([{ transform: "translateY(" + (a.top - z.top) + "px)" }, { transform: "none" }], { duration: 520, easing: "cubic-bezier(.16,1,.3,1)" });
                else el.animate([{ opacity: 0, transform: "translateY(14px)" }, { opacity: 1, transform: "none" }], { duration: 480, easing: "cubic-bezier(.16,1,.3,1)" });
            });
        });
    }
    const evl = $("#evlist2");
    if (evl) flipFilter($("#evfilters"), () => $$("li", evl), (el, f) => el.classList.contains("evm") || el.dataset.c === f, () => {
        $$(".evm", evl).forEach(m => m.hidden = !$$('.evi[data-m="' + m.dataset.m + '"]', evl).some(x => !x.hidden));
        const n = $$(".evi", evl).filter(x => !x.hidden).length, s = $("#evcount"); if (s) s.textContent = n + (n === 1 ? " event" : " events");
    });

    /* ---------- 7. centres: the reader panel follows the index ---------- */
    const cidx = $("#cindex"), panel = $("#creader");
    if (cidx && panel) {
        const code = $(".cr-code", panel), name = $(".cr-name", panel), field = $(".cr-field", panel), desc = $(".cr-desc", panel), art = $(".cr-art", panel), link = $(".cr-link", panel), num = $(".cr-num", panel);
        let cur = -1;
        function show(i) {
            if (i === cur) return; cur = i; const c = CENTRES_FULL[i];
            $$(".cx", cidx).forEach(a => a.classList.toggle("on", +a.dataset.i === i));
            panel.classList.remove("swap"); void panel.offsetWidth; panel.classList.add("swap");
            num.textContent = String(i + 1).padStart(2, "0") + " / " + CENTRES_FULL.length; code.textContent = c[0]; name.textContent = c[1]; field.textContent = c[4]; desc.textContent = c[2];
            link.href = c[3]; link.setAttribute("aria-label", "Visit " + c[1]);
            art.innerHTML = window.motif ? motif(i) : "";
        }
        cidx.addEventListener("pointerover", e => { const a = e.target.closest(".cx"); if (a && !a.parentElement.hidden) show(+a.dataset.i) });
        cidx.addEventListener("focusin", e => { const a = e.target.closest(".cx"); if (a) show(+a.dataset.i) });
        show(10); /* NSRCEL leads */
        flipFilter($("#cfields"), () => $$("li", cidx), (el, f) => CENTRES_FULL[+$(".cx", el).dataset.i][4] === f, f => {
            const first = $$("li", cidx).find(li => !li.hidden); if (first) show(+$(".cx", first).dataset.i);
        });
    }

    /* ---------- 8. live reduced-motion switch ---------- */
    reduce.addEventListener("change", () => root.classList.toggle("still", reduce.matches));
    root.classList.toggle("still", reduce.matches);
})();
